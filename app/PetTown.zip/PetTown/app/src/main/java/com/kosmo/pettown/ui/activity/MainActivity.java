package com.kosmo.pettown.ui.activity;

import android.Manifest;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.animation.OvershootInterpolator;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.kosmo.pettown.R;
import com.kosmo.pettown.Utils;
import com.kosmo.pettown.ui.adapter.FeedAdapter;
import com.kosmo.pettown.ui.adapter.FeedItemAnimator;
import com.kosmo.pettown.ui.view.FeedContextMenu;
import com.kosmo.pettown.ui.view.FeedContextMenuManager;

import java.util.List;
import java.util.Vector;

import butterknife.BindView;
import butterknife.OnClick;


public class MainActivity extends BaseDrawerActivity implements FeedAdapter.OnFeedItemClickListener,
        FeedContextMenu.OnFeedContextMenuItemClickListener {
    public static final String ACTION_SHOW_LOADING_ITEM = "action_show_loading_item";
    public int page = 1;



    private static final int ANIM_DURATION_TOOLBAR = 300;
    private static final int ANIM_DURATION_FAB = 400;
    @BindView(R.id.refresh_layout)
    SwipeRefreshLayout swipe;
    @BindView(R.id.rvFeed)
    RecyclerView rvFeed;
    @BindView(R.id.btnCreate)
    FloatingActionButton fabCreate;
    @BindView(R.id.content)
    CoordinatorLayout clContent;

    private FeedAdapter feedAdapter;

    private boolean pendingIntroAnimation;

    //권한을 위한 변수들

    public static final int MY_REQUEST_PERMISSION_EXTERNAL=1;

    //현재 앱에서 필요한 권한들
    private String[] permissions = {
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE
    };
    //허용이 안된 권한들을 저장할 컬렉션
    final List<String> denyPermissions = new Vector<String>();

    //카메라 갤러리
    private static final int CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE=1;
    private static final int GALLERY_IMAGE_ACTIVITY_REQUEST_CODE=2;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(FeedAdapter.TAG,"Main_onCreate");
        setContentView(R.layout.activity_main);
        setupFeed();

        if (savedInstanceState == null) {
            pendingIntroAnimation = true;
        } else {
            feedAdapter.updateItems(false,page);
        }
        swipe.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                setupFeed();
                page = 1;
                feedAdapter.updateItems(true,page);
                swipe.setRefreshing(false);
            }
        });
    }

    /* 피드 설정 */
    private void setupFeed() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this) {
            @Override
            protected int getExtraLayoutSpace(RecyclerView.State state) {
                return 300;
            }
        };
        rvFeed.setLayoutManager(linearLayoutManager);

        feedAdapter = new FeedAdapter(this);
        feedAdapter.setOnFeedItemClickListener(this);
        rvFeed.setAdapter(feedAdapter);

        rvFeed.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                FeedContextMenuManager.getInstance().onScrolled(recyclerView, dx, dy);
                if(!rvFeed.canScrollVertically(1)){
                    Log.i(FeedAdapter.TAG,"onScrolled이 바닥"+page);
                    feedAdapter.updateItems(true,++page);
                }
            }
        });
        rvFeed.setItemAnimator(new FeedItemAnimator());

    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (ACTION_SHOW_LOADING_ITEM.equals(intent.getAction())) {
            showFeedLoadingItemDelayed();
        }
    }

    private void showFeedLoadingItemDelayed() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                rvFeed.smoothScrollToPosition(0);
                feedAdapter.showLoadingView();
            }
        }, 500);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        if (pendingIntroAnimation) {
            pendingIntroAnimation = false;
            startIntroAnimation();
        }
        return true;
    }

    private void startIntroAnimation() {
        Log.i(FeedAdapter.TAG,"startIntroAnimation 입장");
        fabCreate.setTranslationY(2 * getResources().getDimensionPixelOffset(R.dimen.btn_fab_size));

        int actionbarSize = Utils.dpToPx(56);
        getToolbar().setTranslationY(-actionbarSize);
        getIvLogo().setTranslationY(-actionbarSize);
        getInboxMenuItem().getActionView().setTranslationY(-actionbarSize);

        getToolbar().animate()
                .translationY(0)
                .setDuration(ANIM_DURATION_TOOLBAR)
                .setStartDelay(300);
        getIvLogo().animate()
                .translationY(0)
                .setDuration(ANIM_DURATION_TOOLBAR)
                .setStartDelay(400);
        getInboxMenuItem().getActionView().animate()
                .translationY(0)
                .setDuration(ANIM_DURATION_TOOLBAR)
                .setStartDelay(500)
                .setListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        startContentAnimation();
                    }
                })
                .start();
    }

    private void startContentAnimation() {
        Log.i(FeedAdapter.TAG,"startContentAnimation입장");
        fabCreate.animate()
                .translationY(0)
                .setInterpolator(new OvershootInterpolator(1.f))
                .setStartDelay(300)
                .setDuration(ANIM_DURATION_FAB)
                .start();
        feedAdapter.updateItems(true,page);
    }

    @Override
    public void onCommentsClick(View v, int position) {
        final Intent intent = new Intent(this, CommentsActivity.class);
        int[] startingLocation = new int[2];
        v.getLocationOnScreen(startingLocation);
        //여기서 v는 선택된 전체 카드뷰
        String pno = v.findViewById(R.id.btnComments).getTag().toString();
        Log.i(FeedAdapter.TAG,"저장된 값"+pno);
        intent.putExtra(CommentsActivity.ARG_DRAWING_START_LOCATION, startingLocation[1]);
        intent.putExtra("pno",pno);
        startActivity(intent);
        overridePendingTransition(0, 0);
    }

    @Override
    public void onMoreClick(View v, int itemPosition) {
        FeedContextMenuManager.getInstance().toggleContextMenuFromView(v, itemPosition, this);
    }

    @Override
    public void onProfileClick(View v) {
        int[] startingLocation = new int[2];
        v.getLocationOnScreen(startingLocation);
        startingLocation[0] += v.getWidth() / 2;
        UserProfileActivity.startUserProfileFromLocation(startingLocation, this);
        overridePendingTransition(0, 0);
    }

    @Override
    public void onReportClick(int feedItem) {
        FeedContextMenuManager.getInstance().hideContextMenu();
    }

    @Override
    public void onSharePhotoClick(int feedItem) {
        Intent intent = new Intent(this, TeachableActivity.class);
        startActivity(intent);
        //FeedContextMenuManager.getInstance().hideContextMenu();
    }

    @Override
    public void onCopyShareUrlClick(int feedItem) {
        FeedContextMenuManager.getInstance().hideContextMenu();
    }

    @Override
    public void onCancelClick(int feedItem) {
        FeedContextMenuManager.getInstance().hideContextMenu();
    }
    //작성하기 버튼 > 갤러리 > 카메라 등 접근 권한 필요
    @OnClick(R.id.btnCreate)
    public void onTakePhotoClick() {
        //3]권한 요청하기
        //마쉬멜로우 이후 버전부터 사용자에게 권한 요청보낸다
        if(Build.VERSION.SDK_INT >=23) {
            requestUserPermissions();
        }//if
        //모두 허가시
        if(denyPermissions.size()==0){
            /*
            Intent intent = new Intent(Intent.ACTION_PICK);
            intent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,"image/*");
            startActivityForResult(intent,GALLERY_IMAGE_ACTIVITY_REQUEST_CODE);
            */
            /*
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(intent,CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE);
            */
            Intent intent = new Intent(this, WriteActivity.class);
            startActivity(intent);
        }
        /*
        int[] startingLocation = new int[2];
        fabCreate.getLocationOnScreen(startingLocation);
        startingLocation[0] += fabCreate.getWidth() / 2;
        TakePhotoActivity.startCameraFromLocation(startingLocation, this);
        overridePendingTransition(0, 0);
        */
    }

    public void showLikedSnackbar() {
        Snackbar.make(clContent, "Liked!", Snackbar.LENGTH_SHORT).show();
    }
    public void showDisLikedSnackbar() {
        Snackbar.make(clContent, "Like Cancel", Snackbar.LENGTH_SHORT).show();
    }


    //사용자에게 권한을 요청하는 메소드(안드로이드 6.0이상부터 추가됨)
    private boolean requestUserPermissions() {
        Log.i(FeedAdapter.TAG,"denyPermissions수:"+denyPermissions.size());
        for (String permission : permissions) {
            Log.i(FeedAdapter.TAG,"권한 요청들:"+permission);
            //권한 획득시 0,없을시 -1
            int checkSelfPermission = ActivityCompat.checkSelfPermission(this, permission);
            //권한이 없는 경우
            Log.i(FeedAdapter.TAG,"군한이 없는 요청들:"+checkSelfPermission);
            if (checkSelfPermission == PackageManager.PERMISSION_DENIED) {
                denyPermissions.add(permission);
            }
        }
        //권한이 없는게 있다면
        if (denyPermissions.size()!=0) {
            new AlertDialog.Builder(this)
                    .setIcon(android.R.drawable.ic_menu_compass)
                    .setCancelable(false)
                    .setTitle("권한 요청")
                    .setMessage("권한을 허용해야만 이 앱을 정상적으로 사용할 수 있습니다")
                    .setPositiveButton("예", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //사용자에게 없는 권한 요청
                            ActivityCompat.requestPermissions(MainActivity.this, denyPermissions.toArray(new String[denyPermissions.size()]), MainActivity.MY_REQUEST_PERMISSION_EXTERNAL);
                        }
                    })
                    .setNegativeButton("아니오", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                           //아니오 눌렀을때 실행할 코드
                        }
                    }).show();

            return false;
        }
        return true;//모든 권한이 있는 경우
        //onRequestPermissionsResult오버라이딩 하자

    }////////////requestUserPermission


    //아래 메소드는 프래그먼트에서 오버라이딩 하지말고
    //프래그 먼트를 붙인 액티비티에서 오버라이딩 해라
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        switch(requestCode){
        case MainActivity.MY_REQUEST_PERMISSION_EXTERNAL:
            //사용자가  allow(허용)나 deny를 누른 경우
            if(grantResults.length > 0 ){
                for (int i = 0; i < permissions.length; i++) {
                    if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {//허용한 경우
                        Log.i(FeedAdapter.TAG,":허용");
                        //허용시 해당 구너한 삭제
                        denyPermissions.remove(permissions[i]);

                    }
                    else{//사용자가  deny(거부)를 누른 경우
                        //이동만 안하면된다
                    }
                }
            }
        }////switch
    }////////////////onRequestPermissionsResult

    //아이디,토큰? 삭제
    @Override
    protected void onDestroy() {
        super.onDestroy();
        SharedPreferences preferences = getSharedPreferences("loginInfo",MODE_PRIVATE);
        SharedPreferences.Editor editor =preferences.edit();
        editor.remove("id");
        editor.commit();
    }/////onDestroy

}/////////