package com.kosmo.pettown.ui.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ClipData;
import android.content.ContentUris;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.kosmo.pettown.R;
import com.kosmo.pettown.ui.adapter.FeedAdapter;
import com.kosmo.pettown.ui.utils.GetFilePathToUri;

import org.jetbrains.annotations.NotNull;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import butterknife.BindView;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class WriteActivity extends AppCompatActivity {

    ImageView gelImg1;
    ImageView gelImg2;
    ImageView gelImg3;
    ImageView gelImg4;
    ImageView gelImg5;
    ImageView gelImg6;
    EditText pContent;
    EditText pTag;
    String photoImagePath;
    //업로드용 파일리스트
    List<File> fileList= new Vector<File>();


    //카메라 갤러리
    private static final int CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE = 1;
    private static final int GALLERY_IMAGE_ACTIVITY_REQUEST_CODE = 2;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_write);
        //바인딩
        gelImg1 = findViewById(R.id.gelImg1);
        gelImg2 = findViewById(R.id.gelImg2);
        gelImg3 = findViewById(R.id.gelImg3);
        gelImg4 = findViewById(R.id.gelImg4);
        gelImg5 = findViewById(R.id.gelImg5);
        gelImg6 = findViewById(R.id.gelImg6);
        pContent = findViewById(R.id.pContent);
        pTag = findViewById(R.id.pTag);
        findViewById(R.id.multiImageBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                doTakeMultiAlbumAction();
            }
        });

        findViewById(R.id.cameraBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent,CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE);
            }
        });
        findViewById(R.id.insertPet).setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View view) {
                //글작성 버튼
                sendImageToServer("pcontent="+pContent.getText().toString()
                        ,"pttag="+pTag.getText().toString());
            }
        });
        findViewById(R.id.petCancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //취소 버튼
                onBackPressed();
            }
        });
    }//////oncreate

    public void doTakeMultiAlbumAction() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,"image/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
        startActivityForResult(intent,GALLERY_IMAGE_ACTIVITY_REQUEST_CODE);
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        Log.i(FeedAdapter.TAG,"onActivityResult write");
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE){
            Log.i(FeedAdapter.TAG,"requestCode write");
            if(resultCode == Activity.RESULT_OK){
                if(data== null){
                    Toast.makeText(WriteActivity.this,"카메라로 사진 찍기 실패",Toast.LENGTH_SHORT).show();
                    return;
                }
                Bitmap bmp=(Bitmap)data.getExtras().get("data");
                Log.i(FeedAdapter.TAG,"Bitmap write");

                //아래는 용량이 클 경우 OutOfMemoryException 발생이 예상되어 압축
                //ByteArrayOutputStream stream = new ByteArrayOutputStream();
                //bmp.compress(Bitmap.CompressFormat.PNG, 100, stream);
                //byte[] byteArray = stream.toByteArray();
                // convert byte array to Bitmap
                //Bitmap bitmap = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
                //압축된 이미지를 이미지뷰에표시
                //gelImg1.setImageBitmap(bitmap);

                //압축이 안된 이미지를 이미지뷰에 표시
                //gelImg1.setImageBitmap(bmp);

                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
                File file=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
                photoImagePath=file.getAbsolutePath()+File.separator+dateFormat.format(new Date())+"_camera.png";

                file = new File(photoImagePath);

                ///갤러리에 촬영한 사진 추가하기
                BufferedOutputStream bos = null;
                try {
                    bos = new BufferedOutputStream(
                            new FileOutputStream(file));

                    bmp.compress(Bitmap.CompressFormat.PNG,100,bos);//이미지가 용량이 클 경우
                    //OutOfMemoryException 발생할수 있음.그래서 압축
                    //사진을 앨범에 보이도록 갤러리앱에 방송을 보내기
                    WriteActivity.this.sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(file)));
                    bos.flush();
                    bos.close();
                    //https://square.github.io/okhttp/
                    //1.그레이들에 okhttp3라이브러리 추가
                    //서버로 전송하기
                    //sendImageToServer(file);
                    //파일리스트에 추가하니 에러
                    //fileList.add(0,file);
                }
                catch(Exception e){e.printStackTrace();}
                Log.i("com.kosmo.kosmoapp",photoImagePath);
            }
        }
        else if(requestCode == GALLERY_IMAGE_ACTIVITY_REQUEST_CODE){
            Log.i(FeedAdapter.TAG,"GALLERY_IMAGE write");
            //갤러리에 있는 이미지를 이미지뷰에 표시하기
            if(resultCode== Activity.RESULT_OK){
                if(data== null){
                    Toast.makeText(WriteActivity.this,"이미지를 가져올수 없어요",Toast.LENGTH_SHORT).show();
                    return;
                }
                ClipData clipData = data.getClipData();
                Log.i(FeedAdapter.TAG,"clipData 갯수"+clipData.getItemCount());
                if(clipData.getItemCount() > 6){
                    Toast.makeText(WriteActivity.this,"최대 6장까지 이미지업로드가 가능합니다",Toast.LENGTH_SHORT).show();
                    return;
                }
                else {
                    fileList.clear();
                    for(int i=0; i<clipData.getItemCount();i++) {
                        //갤러리에 있는 이미지 선택
                        Uri selectedImageUri = clipData.getItemAt(i).getUri();
                        Log.i(FeedAdapter.TAG, "selectedImageUri write" + selectedImageUri);
                        //선택된 이미지의 Uri로 이미지뷰에 표시

                        //gelImg1.setImageURI(selectedImageUri);
                        Log.i(FeedAdapter.TAG, "setImageURI write");
                        //파일객체 생성
                        File file = new File(GetFilePathToUri.getRealPathFromURI(this,selectedImageUri));
                        fileList.add(file);

                    }
                }
            }
        }////////////
        showImageViews();
    }///////////////

    //서버로 이미지를 전송하는 메소드
    private void sendImageToServer(String pContentParam,String pTagParam){
        Log.i(FeedAdapter.TAG, "sendImageToServer입장");
        //요청바디 설정
        MultipartBody.Builder requestBody=new MultipartBody.Builder()
                .setType(MultipartBody.FORM);
                //파라미터명은 picture

        Log.i(FeedAdapter.TAG, "fileList.size():"+fileList.size());
        for(int i =0;i<fileList.size();i++) {
            Log.i(FeedAdapter.TAG, "sendImageToServer 포문"+i);
            requestBody.addFormDataPart("picture", fileList.get(i).getName(), RequestBody.create(fileList.get(i), MediaType.parse("image/png")));
        }
        //요청 객체 생성
        Request request=new Request.Builder()
                .url("http://10.0.2.2:8080/pettown/androidUpload")
                .post(requestBody.build())
                .build();
        OkHttpClient client= new OkHttpClient();
        //비동기로 요청 보내기
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Log.i(FeedAdapter.TAG, "sendImageToServer 실패");
                e.printStackTrace();
            }
            //서버로부터 응답받는 경우
            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                String result = response.body().string();
                Log.i(FeedAdapter.TAG, result);
                new PetInsertAsyncTask().execute("http://10.0.2.2:8080/pettown/petInsert",
                        pContentParam,pTagParam,"primage="+result,
                        "id="+"lee@naver.com");

            }
        });

    }

    //파일리스트에서 뿌려주기
    private void showImageViews(){
        Log.i(FeedAdapter.TAG, "showImageViews:"+fileList.size());
        clearView();
        for(int i=0;i<fileList.size();i++){
            switch (i){
                case 0:
                    gelImg1.setImageURI(getUriFromPath(fileList.get(i).getAbsolutePath()));
                    break;
                case 1:
                    gelImg2.setImageURI(getUriFromPath(fileList.get(i).getAbsolutePath()));
                    break;
                case 2:
                    gelImg3.setImageURI(getUriFromPath(fileList.get(i).getAbsolutePath()));
                    break;
                case 3:
                    gelImg4.setImageURI(getUriFromPath(fileList.get(i).getAbsolutePath()));
                    break;
                case 4:
                    gelImg5.setImageURI(getUriFromPath(fileList.get(i).getAbsolutePath()));
                    break;
                case 5:
                    gelImg6.setImageURI(getUriFromPath(fileList.get(i).getAbsolutePath()));
                    break;
                default:
                    Toast.makeText(this,"최대 6장까지만 업로드 가능",Toast.LENGTH_SHORT).show();
                    return;
            }
        }
    }/////////showImageViews

    private void clearView(){
        gelImg1.setImageResource(0);
        gelImg2.setImageResource(0);
        gelImg3.setImageResource(0);
        gelImg4.setImageResource(0);
        gelImg5.setImageResource(0);
        gelImg6.setImageResource(0);
    }////////clearView

    public Uri getUriFromPath(String path){
        String fileName= path;
        Uri fileUri = Uri.parse( fileName );
        String filePath = fileUri.getPath();
        Cursor cursor = getContentResolver().query( MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                null, "_data = '" + filePath + "'", null, null );
        cursor.moveToNext();
        int id = cursor.getInt( cursor.getColumnIndex( "_id" ) );
        Uri uri = ContentUris.withAppendedId( MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id );
        return uri;
    }//////////getUriFromPath

    //댓글 입력
    public class PetInsertAsyncTask extends AsyncTask<String,Void,Void> {
        @Override
        protected Void doInBackground(String... params) {
            StringBuffer buf = new StringBuffer();
            try {
                URL url = new URL(params[0]);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                //1.POST방식으로 통신 설정:POST방식으로 설정시 OutPutStream으로 파라미터를 서버에 전달
                conn.setRequestMethod("POST");//디폴트는 GET방식
                //setRequestMethod("GET")으로 설정하더라도 아래 코드(setDoInput(true))가 추가되면 POST방식으로 변경된다.
                conn.setDoInput(true);
                //연결제한시간
                conn.setConnectTimeout(3000);
                // 요청 파라미터 출력(서버로 보내는 출력)
                // - 파라미터는 쿼리 문자열의 형식으로 지정
                // - 파라미터의 값으로 한국어 등을 송신하는 경우는 URL 인코딩을 해야 함.
                // Request Body에 Data를 담기위해 OutputStream 객체를 생성.
                if(params.length !=1){//파라미터 전달
                    OutputStream out=conn.getOutputStream();
                    //요청바디에 데이타가 설정된다
                    out.write(params[1].getBytes());
                    out.write("&".getBytes());
                    out.write(params[2].getBytes());
                    out.write("&".getBytes());
                    out.write(params[3].getBytes());
                    out.write("&".getBytes());
                    out.write(params[4].getBytes());
                    out.close();
                }

                //서버에 요청 및 응답코드 받기
                int responseCode = conn.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    //연결된 커넥션에서 서버에서 보낸 데이타 읽기
                    BufferedReader br =
                            new BufferedReader(
                                    new InputStreamReader(conn.getInputStream(), "UTF-8"));
                    String line;
                    while ((line = br.readLine()) != null) {
                        buf.append(line);
                    }
                    br.close();
                    //JSON데이타 파싱
                    Log.i(FeedAdapter.TAG, buf.toString());
                }//성공시 if
            }//try///
            catch(Exception e){e.printStackTrace();}
            return null;
        }
        @Override
        protected void onPostExecute(Void aVoid) {
            //어댑터에게 데이터 변경 통지
            //notifyItemRangeInserted(0, petReplyItems.size());
            //notifyDataSetChanged();
            Log.i(FeedAdapter.TAG, "onPostExecute : 쓰레드 종료");
            onBackPressed();
        }
    }/////////////////////ItemsAsyncTask

}//////Class