package com.kosmo.pettown.ui.adapter;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.kosmo.pettown.R;
import com.kosmo.pettown.ui.activity.CommentsActivity;
import com.kosmo.pettown.ui.activity.MainActivity;
import com.kosmo.pettown.ui.item.PetReplyItem;
import com.kosmo.pettown.ui.utils.RoundedTransformation;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by froger_mcs on 11.11.14.
 */
public class CommentsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private Context context;
    private int lastAnimatedPosition = -1;
    private int avatarSize;
    //총 댓글 저장
    private final List<PetReplyItem> petReplyItems = new ArrayList<PetReplyItem>();
    //임시 댓글 저장
    private final List<PetReplyItem> petReplyItemsTemp = new ArrayList<PetReplyItem>();
    //쓰레드 객체
    AsyncTask replyAsyncTask;

    private boolean animationsLocked = false;
    private boolean delayEnterAnimation = true;

    public CommentsAdapter(Context context) {
        this.context = context;
        avatarSize = context.getResources().getDimensionPixelSize(R.dimen.comment_avatar_size);
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Log.i(FeedAdapter.TAG,"댓글 onCreateViewHolder");
        final View view = LayoutInflater.from(context).inflate(R.layout.item_comment, parent, false);
        CommentViewHolder cellFeedViewHolder = new CommentViewHolder(view);
        setupClickableViews(view, cellFeedViewHolder);
        return new CommentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int position) {
        Log.i(FeedAdapter.TAG,"댓글 onBindViewHolder");
        runEnterAnimation(viewHolder.itemView, position);
        CommentViewHolder holder = (CommentViewHolder)viewHolder;
        holder.bindView(petReplyItems.get(position));

    }

    private void runEnterAnimation(View view, int position) {
        Log.i(FeedAdapter.TAG,"댓글 runEnterAnimation");
        if (animationsLocked) return;

        if (position > lastAnimatedPosition) {
            lastAnimatedPosition = position;
            view.setTranslationY(100);
            view.setAlpha(0.f);
            view.animate()
                    .translationY(0).alpha(1.f)
                    .setStartDelay(delayEnterAnimation ? 20 * (position) : 0)
                    .setInterpolator(new DecelerateInterpolator(2.f))
                    .setDuration(300)
                    .setListener(new AnimatorListenerAdapter() {
                        @Override
                        public void onAnimationEnd(Animator animation) {
                            animationsLocked = true;
                        }
                    })
                    .start();
        }
    }

    @Override
    public int getItemCount() {
        return petReplyItems.size();
    }

    public void updateItems(String pno) {
        Log.i(FeedAdapter.TAG,"댓글 updateItems");
        replyAsyncTask =
                new ReplysAsyncTask().execute("http://10.0.2.2:8080/pettown/replys?pNo="+pno);
        //제일먼저 들어옴 여기서 쓰레드 호출
        //itemsCount = 10;
        //이걸로 값 변화하는듯?
        //notifyDataSetChanged();
    }

    public void addItem(String pno,String content) {
        Log.i(FeedAdapter.TAG,"댓글 addItem");
        String id = "lee@naver.com";
        Log.i(FeedAdapter.TAG,"댓글 addItem 내용:"+content);
        new ReplyInsertAsyncTask().execute("http://10.0.2.2:8080/pettown/replyInsert?pno="+pno+"&content="+content+"&id="+id);
        new ReplysAsyncTask().execute("http://10.0.2.2:8080/pettown/replys?pNo="+pno);
        //notifyItemInserted(itemsCount - 1);
    }

    public void setAnimationsLocked(boolean animationsLocked) {
        this.animationsLocked = animationsLocked;
    }

    public void setDelayEnterAnimation(boolean delayEnterAnimation) {
        this.delayEnterAnimation = delayEnterAnimation;
    }
    //바인드?
    public static class CommentViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.ivUserAvatar)
        ImageView ivUserAvatar;
        @BindView(R.id.tvComment)
        TextView tvComment;
        @BindView(R.id.commentUserName)
        TextView commentUserName;

        PetReplyItem petReplyItem;

        public CommentViewHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);
        }

        @SuppressLint("NewApi")
        public void bindView(PetReplyItem petReplyItem) {
            Log.i(FeedAdapter.TAG,"댓글 bindView");

            this.petReplyItem = petReplyItem;
            int adapterPosition = getAdapterPosition();
            ivUserAvatar.setBackground(new ShapeDrawable(new OvalShape()));
            ivUserAvatar.setClipToOutline(true);
            //실제 사진
            Picasso.get().load(petReplyItem.getMpPhoto()).into(ivUserAvatar);
            //ivFeedCenter.setImageResource(adapterPosition % 2 == 0 ? R.drawable.img_feed_center_1 : R.drawable.img_feed_center_2);
            //여기에 텍스트 넣어야하는데 이미지뷰임 수정 필요
            Log.i(FeedAdapter.TAG,"텍스트뷰 세팅전");
            tvComment.setText(petReplyItem.getPrContent());
            commentUserName.setText(petReplyItem.getName());
        }
    }
    //쓰레드 종료
    /*
    public void cancelAsyncTask(){
        if(replyAsyncTask != null)
            Log.i(FeedAdapter.TAG,"cancelAsyncTask입장");
            replyAsyncTask.cancel(true);
    }
    */

    //클릭설정
    private void setupClickableViews(final View view, final CommentViewHolder CommentViewHolder) {
        /*
        cellFeedViewHolder.btnComments.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onFeedItemClickListener.onCommentsClick(view, cellFeedViewHolder.getAdapterPosition());
            }
        });
        */
    }

    //댓글 리스트 받기
    public class ReplysAsyncTask extends AsyncTask<String,Void,Void> {
        @Override
        protected Void doInBackground(String... params) {
            //무한루프?
            Log.i(FeedAdapter.TAG, "isCancelled" + isCancelled());
            petReplyItemsTemp.clear();
            StringBuffer buf = new StringBuffer();
            try {
                URL url = new URL(params[0]);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                //서버에 요청 및 응답코드 받기
                int responseCode = conn.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    //연결된 커넥션에서 서버에서 보낸 데이타 읽기
                    BufferedReader br =
                            new BufferedReader(
                                    new InputStreamReader(conn.getInputStream(), "UTF-8"));
                    String line;
                    while ((line = br.readLine()) != null) {
                        buf.append(line);
                    }
                    br.close();
                    //JSON데이타 파싱
                    Log.i(FeedAdapter.TAG, buf.toString());
                    JSONArray array = new JSONArray(buf.toString());
                    if (array.length() != petReplyItems.size()) {
                        for (int i = 0; i < array.length(); i++) {
                            Log.i(FeedAdapter.TAG, "for문 입장 횟수" + array.length());
                            JSONObject json = array.getJSONObject(i);
                            String prNo = json.getString("prNo");
                            String prContent = json.getString("prContent");
                            Date prPostdate = new Date(Long.parseLong(json.getString("prPostdate")));
                            String pNo = json.getString("pNo");
                            String id = json.getString("id");
                            String name = json.getString("name");
                            String mpPhoto = FeedAdapter.IMAGE_URL + "upload1.jpg";
                            String photoStr = json.getString("mpPhoto");
                            Log.i(FeedAdapter.TAG, "이미지:" + photoStr);
                            if (photoStr != null && photoStr != "null") {
                                mpPhoto = FeedAdapter.IMAGE_URL + json.getString("mpPhoto");
                            }
                            Log.i(FeedAdapter.TAG, "번호" + pNo);
                            Log.i(FeedAdapter.TAG, "내용" + prContent);
                            Log.i(FeedAdapter.TAG, "날짜" + prPostdate);
                            Log.i(FeedAdapter.TAG, "아이디" + id);
                            Log.i(FeedAdapter.TAG, "이름" + name);
                            Log.i(FeedAdapter.TAG, "댓글" + prNo);
                            Log.i(FeedAdapter.TAG, "이미지" + mpPhoto);
                            PetReplyItem item = new PetReplyItem(prNo, prContent, prPostdate, id, pNo, name, mpPhoto);
                            petReplyItemsTemp.add(item);
                        }
                        Log.i(FeedAdapter.TAG, "추가");
                        petReplyItems.clear();
                        petReplyItems.addAll(petReplyItemsTemp);
                        notifyItemRangeRemoved(0, petReplyItems.size());
                        notifyItemRangeInserted(0, petReplyItems.size());
                    }
                }//성공시 if
            }//try///
            catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }
        @Override
        protected void onPostExecute(Void aVoid) {
            //어댑터에게 데이터 변경 통지
            //notifyItemRangeInserted(0, petReplyItems.size());
            //notifyDataSetChanged();
            Log.i(FeedAdapter.TAG, "onPostExecute : 쓰레드 종료");
        }
    }/////////////////////ItemsAsyncTask


    //댓글 입력
    public class ReplyInsertAsyncTask extends AsyncTask<String,Void,Void> {
        @Override
        protected Void doInBackground(String... params) {
            //무한루프?
            Log.i(FeedAdapter.TAG,"isCancelled"+isCancelled());
            StringBuffer buf = new StringBuffer();
            try {
                URL url = new URL(params[0]);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                //서버에 요청 및 응답코드 받기
                int responseCode = conn.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    //연결된 커넥션에서 서버에서 보낸 데이타 읽기
                    BufferedReader br =
                            new BufferedReader(
                                    new InputStreamReader(conn.getInputStream(), "UTF-8"));
                    String line;
                    while ((line = br.readLine()) != null) {
                        buf.append(line);
                    }
                    br.close();
                    //JSON데이타 파싱
                    Log.i(FeedAdapter.TAG, buf.toString());
                }//성공시 if
            }//try///
            catch(Exception e){e.printStackTrace();}
            return null;
        }
        @Override
        protected void onPostExecute(Void aVoid) {
            //어댑터에게 데이터 변경 통지
            //notifyItemRangeInserted(0, petReplyItems.size());
            //notifyDataSetChanged();
            Log.i(FeedAdapter.TAG, "onPostExecute : 쓰레드 종료");
        }
    }/////////////////////ItemsAsyncTask

}//////class
