package com.kosmo.pettown.ui.adapter;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.kosmo.pettown.R;
import com.kosmo.pettown.ui.item.PetReplyItem;
import com.kosmo.pettown.ui.utils.RoundedTransformation;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by froger_mcs on 11.11.14.
 */
public class CommentsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private Context context;
    private int itemsCount = 0;
    private int lastAnimatedPosition = -1;
    private int avatarSize;
    //총 피드 저장?
    private final List<PetReplyItem> petReplyItems = new ArrayList<PetReplyItem>();
    //임시 피드 저장
    private final List<PetReplyItem> petReplyItemsTemp = new ArrayList<PetReplyItem>();
    private boolean animationsLocked = false;
    private boolean delayEnterAnimation = true;

    public CommentsAdapter(Context context) {
        this.context = context;
        avatarSize = context.getResources().getDimensionPixelSize(R.dimen.comment_avatar_size);
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Log.i(FeedAdapter.TAG,"댓글 onCreateViewHolder");
        final View view = LayoutInflater.from(context).inflate(R.layout.item_comment, parent, false);
        return new CommentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int position) {
        Log.i(FeedAdapter.TAG,"댓글 onBindViewHolder");
        runEnterAnimation(viewHolder.itemView, position);
        CommentViewHolder holder = (CommentViewHolder) viewHolder;
        switch (position % 3) {
            case 0:
                holder.tvComment.setText("Lorem ipsum dolor sit amet, consectetur adipisicing elit.");
                break;
            case 1:
                holder.tvComment.setText("Cupcake ipsum dolor sit amet bear claw.");
                break;
            case 2:
                holder.tvComment.setText("Cupcake ipsum dolor sit. Amet gingerbread cupcake. Gummies ice cream dessert icing marzipan apple pie dessert sugar plum.");
                break;
        }

        Picasso.get()
                .load(R.drawable.ic_launcher)
                .centerCrop()
                .resize(avatarSize, avatarSize)
                .transform(new RoundedTransformation())
                .into(holder.ivUserAvatar);
    }

    private void runEnterAnimation(View view, int position) {
        Log.i(FeedAdapter.TAG,"댓글 runEnterAnimation");
        if (animationsLocked) return;

        if (position > lastAnimatedPosition) {
            lastAnimatedPosition = position;
            view.setTranslationY(100);
            view.setAlpha(0.f);
            view.animate()
                    .translationY(0).alpha(1.f)
                    .setStartDelay(delayEnterAnimation ? 20 * (position) : 0)
                    .setInterpolator(new DecelerateInterpolator(2.f))
                    .setDuration(300)
                    .setListener(new AnimatorListenerAdapter() {
                        @Override
                        public void onAnimationEnd(Animator animation) {
                            animationsLocked = true;
                        }
                    })
                    .start();
        }
    }

    @Override
    public int getItemCount() {
        return itemsCount;
    }

    public void updateItems(int pno) {
        Log.i(FeedAdapter.TAG,"댓글 updateItems");
        new ReplysAsyncTask().execute();
        //제일먼저 들어옴 여기서 쓰레드 호출
        //itemsCount = 10;
        //이걸로 값 변화하는듯?
        notifyDataSetChanged();
    }

    public void addItem() {
        Log.i(FeedAdapter.TAG,"댓글 addItem");
        itemsCount++;
        notifyItemInserted(itemsCount - 1);
    }

    public void setAnimationsLocked(boolean animationsLocked) {
        this.animationsLocked = animationsLocked;
    }

    public void setDelayEnterAnimation(boolean delayEnterAnimation) {
        this.delayEnterAnimation = delayEnterAnimation;
    }

    public static class CommentViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.ivUserAvatar)
        ImageView ivUserAvatar;
        @BindView(R.id.tvComment)
        TextView tvComment;
        @BindView(R.id.commentUserName)
        TextView commentUserName;

        PetReplyItem petReplyItem;

        public CommentViewHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);
        }

        public void bindView(PetReplyItem petReplyItem) {
            Log.i(FeedAdapter.TAG,"댓글 bindView");
            /*
            this.petReplyItem = petReplyItem;
            int adapterPosition = getAdapterPosition();
            //실제 사진
            Picasso.get().load(feedItem.getPrImage()).into(ivFeedCenter);
            //ivFeedCenter.setImageResource(adapterPosition % 2 == 0 ? R.drawable.img_feed_center_1 : R.drawable.img_feed_center_2);
            //여기에 텍스트 넣어야하는데 이미지뷰임 수정 필요
            Log.i(TAG,"텍스트뷰 세팅전");
            ivFeedContent.setText(feedItem.getpContent());
            ivUserName.setText(feedItem.getName());
            ivUserProfile.setBackground(new ShapeDrawable(new OvalShape()));
            ivUserProfile.setClipToOutline(true);

            for(int i = 0; i<feedItem.getPetReplyItem().size(); i++){
                if(i==0){
                    ivFeedReplyName0.setText(feedItem.getPetReplyItem().get(i).getName());
                    ivFeedReplyContent0.setText(feedItem.getPetReplyItem().get(i).getPrContent());
                }
                else{
                    ivFeedReplyName1.setText(feedItem.getPetReplyItem().get(i).getName());
                    ivFeedReplyContent1.setText(feedItem.getPetReplyItem().get(i).getPrContent());
                }
            }
            //Comments버튼 눌렀을때 전달할 값(글번호?)
            btnComments.setTag(feedItem.getpNo());
            Log.i(TAG,"글번호바인딩:"+feedItem.getpNo());
            Log.i(TAG,"텍스트뷰 세팅후");
            btnLike.setImageResource(feedItem.getIsLike()!=0 ? R.drawable.ic_heart_red : R.drawable.ic_heart_outline_grey);
            tsLikesCounter.setCurrentText(vImageRoot.getResources().getQuantityString(
                    R.plurals.likes_count, feedItem.getLikeCount(), feedItem.getLikeCount()
            ));
            */
        }

    }

    //댓글 리스트 받기
    public class ReplysAsyncTask extends AsyncTask<String,Void,Void> {
        @Override
        protected Void doInBackground(String... params) {
            petReplyItems.clear();
            StringBuffer buf = new StringBuffer();
            try {
                URL url = new URL(params[0]);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                //서버에 요청 및 응답코드 받기
                int responseCode = conn.getResponseCode();
                if(responseCode==HttpURLConnection.HTTP_OK){
                    //연결된 커넥션에서 서버에서 보낸 데이타 읽기
                    BufferedReader br =
                            new BufferedReader(
                                    new InputStreamReader(conn.getInputStream(),"UTF-8"));
                    String line;
                    while((line=br.readLine())!=null){
                        buf.append(line);
                    }
                    br.close();
                    /*
                    //JSON데이타 파싱
                    Log.i(TAG,buf.toString());
                    JSONArray array= new JSONArray(buf.toString());
                    for(int i=0;i<array.length();i++){
                        Log.i(TAG,"for문 입장 횟수"+array.length());
                        JSONObject json = array.getJSONObject(i);
                        String pNo = json.getString("pNo");
                        String pContent = json.getString("pContent");
                        Date pPostdate = new Date(Long.parseLong(json.getString("pPostdate")));
                        String pCategory = json.getString("pCategory");
                        String id = json.getString("id");
                        String name = json.getString("name");
                        String replyCount = json.getString("replyCount");
                        JSONArray prImages = json.getJSONArray("prImage");
                        String prImage = IMAGE_URL+"upload1.jpg";
                        if(prImages.length() != 0)
                            prImage = IMAGE_URL+json.getJSONArray("prImage").get(0);
                        int likeCount = json.getInt("likeCount");
                        int isLike = json.getInt("isLike");
                        JSONArray petReplys = json.getJSONArray("petReply");
                        List<PetReplyItem> petReplyItemList = new Vector<PetReplyItem>();
                        if(petReplys.length() != 0){
                            for(int k=0;k < petReplys.length();k++){
                                Log.i(TAG,"댓글 포문 입장");
                                PetReplyItem petReplyItem = new PetReplyItem();
                                JSONObject reply = (JSONObject)petReplys.get(k);
                                Log.i(TAG,"댓글내용:"+reply.getString("prContent"));
                                petReplyItem.setId(reply.getString("id"));
                                petReplyItem.setMpPhoto(reply.getString("mpPhoto"));
                                petReplyItem.setPrNo(reply.getString("prNo"));
                                petReplyItem.setPrContent(reply.getString("prContent"));
                                petReplyItem.setName(reply.getString("name"));
                                petReplyItemList.add(petReplyItem);
                            }
                            //"petReply":[{"prNo":"4","prContent":"댓글3333",
                            // "prPostdate":1592146800000,
                            // "id":"park@naver.com",
                            // "pNo":"16","name":"박길동","mpPhoto":null},
                        }
                        Log.i(TAG,"번호"+pNo);
                        *//*
                        Log.i(TAG,"내용"+pContent);
                        Log.i(TAG,"날짜"+pPostdate);
                        Log.i(TAG,"카테고리"+pCategory);
                        Log.i(TAG,"아이디"+id);
                        Log.i(TAG,"이름"+name);
                        Log.i(TAG,"댓글"+replyCount);
                        Log.i(TAG,"이미지"+prImage);
                        Log.i(TAG,"좋아요수"+likeCount);
                        Log.i(TAG,"좋아요 여부"+isLike);
                        *//*
                        FeedAdapter.FeedItem item = new FeedAdapter.FeedItem(pNo,pContent,pPostdate,pCategory,id,name,
                                replyCount,prImage,likeCount,isLike, petReplyItemList);
                        feedItemsTemp.add(item);
                    }
                    feedItems.addAll(feedItemsTemp);
*/
                }
            }
            catch(Exception e){e.printStackTrace();}
            return null;
        }
        @Override
        protected void onPostExecute(Void aVoid) {
            //어댑터에게 데이터 변경 통지
            //notifyItemRangeInserted(0, petReplyItems.size());
        }
    }/////////////////////ItemsAsyncTask


}//////class
