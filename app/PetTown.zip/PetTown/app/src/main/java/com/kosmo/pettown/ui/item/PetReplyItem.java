package com.kosmo.pettown.ui.item;


import java.sql.Date;

//댓글 DTO 클래스
public class PetReplyItem {
    private String prNo;
    private String prContent;
    private Date prPostdate;
    private String id;
    private String pNo;
    private String name;
    //뷰페이지 댓글리스트 사용자 사진
    private String mpPhoto;

    public String getMpPhoto() {
        return mpPhoto;
    }
    public void setMpPhoto(String mpPhoto) {
        this.mpPhoto = mpPhoto;
    }
    //게터 세터
    public String getPrNo() {
        return prNo;
    }
    public void setPrNo(String prNo) {
        this.prNo = prNo;
    }
    public String getPrContent() {
        return prContent;
    }
    public void setPrContent(String prContent) {
        this.prContent = prContent;
    }
    public Date getPrPostdate() {
        return prPostdate;
    }
    public void setPrPostdate(Date prPostdate) {
        this.prPostdate = prPostdate;
    }
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getpNo() {
        return pNo;
    }
    public void setpNo(String pNo) {
        this.pNo = pNo;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
}////////팻 댓글
