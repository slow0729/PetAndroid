package com.kosmo.pettown.ui.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextSwitcher;
import android.widget.TextView;

import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.kosmo.pettown.R;
import com.kosmo.pettown.ui.activity.MainActivity;
import com.kosmo.pettown.ui.item.PetReplyItem;
import com.kosmo.pettown.ui.view.LoadingFeedItemView;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by froger_mcs on 05.11.14.
 */
public class FeedAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    //로그용
    public final static String TAG = "com.kosmo.pettown";
    //이미지 루트 주소
    public final static String IMAGE_URL = "http://10.0.2.2:8080/pettown/upload/";

    public static final String ACTION_LIKE_BUTTON_CLICKED = "action_like_button_button";
    public static final String ACTION_LIKE_IMAGE_CLICKED = "action_like_image_button";

    public static final int VIEW_TYPE_DEFAULT = 1;
    public static final int VIEW_TYPE_LOADER = 2;

    //총 피드 저장?
    private final List<FeedItem> feedItems = new ArrayList<FeedItem>();
    //임시 피드 저장
    private final List<FeedItem> feedItemsTemp = new ArrayList<FeedItem>();

    private Context context;
    private OnFeedItemClickListener onFeedItemClickListener;

    private boolean showLoadingView = false;

    public FeedAdapter(Context context) {
        this.context = context;

    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Log.i(TAG,"onCreateViewHolder");
        if (viewType == VIEW_TYPE_DEFAULT) {
            View view = LayoutInflater.from(context).inflate(R.layout.item_feed, parent, false);
            CellFeedViewHolder cellFeedViewHolder = new CellFeedViewHolder(view);
            setupClickableViews(view, cellFeedViewHolder);
            return cellFeedViewHolder;
        }
        else if (viewType == VIEW_TYPE_LOADER) {
            LoadingFeedItemView view = new LoadingFeedItemView(context);
            view.setLayoutParams(new LinearLayoutCompat.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT)
            );
            return new LoadingCellFeedViewHolder(view);
        }

        return null;
    }

    private void setupClickableViews(final View view, final CellFeedViewHolder cellFeedViewHolder) {
        cellFeedViewHolder.btnComments.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onFeedItemClickListener.onCommentsClick(view, cellFeedViewHolder.getAdapterPosition());
            }
        });
        cellFeedViewHolder.btnMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onFeedItemClickListener.onMoreClick(v, cellFeedViewHolder.getAdapterPosition());
            }
        });
        //피드 샌터? 클릭했을때
        cellFeedViewHolder.ivFeedCenter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int adapterPosition = cellFeedViewHolder.getAdapterPosition();
                int addLike = feedItems.get(adapterPosition).getLikeCount()+1;
                feedItems.get(adapterPosition).setLikeCount(addLike);
                notifyItemChanged(adapterPosition, null);
                //notifyItemChanged(adapterPosition, ACTION_LIKE_IMAGE_CLICKED);
                /*
                if (context instanceof MainActivity) {
                    ((MainActivity) context).showLikedSnackbar();
                }
                */
            }
        });
        //좋아요 버튼 눌렀을때
        cellFeedViewHolder.btnLike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i(TAG,"아이디"+v.getId());
                int adapterPosition = cellFeedViewHolder.getAdapterPosition();
                int likeCount;
                if(feedItems.get(adapterPosition).getIsLike()==1) {
                    likeCount = feedItems.get(adapterPosition).getLikeCount() - 1;
                    feedItems.get(adapterPosition).setIsLike(0);
                }
                else{
                    likeCount = feedItems.get(adapterPosition).getLikeCount() + 1;
                    feedItems.get(adapterPosition).setIsLike(1);
                }
                Log.i(TAG,"좋아요 갯수"+ feedItems.get(adapterPosition).getLikeCount());
                ((ImageView)v).setImageResource(feedItems.get(adapterPosition).getIsLike()==0 ? R.drawable.ic_heart_red : R.drawable.ic_heart_outline_grey);
                feedItems.get(adapterPosition).setLikeCount(likeCount);

                if(feedItems.get(adapterPosition).getIsLike()==1) {
                    notifyItemChanged(adapterPosition, ACTION_LIKE_BUTTON_CLICKED);
                    if (context instanceof MainActivity) {
                        ((MainActivity) context).showLikedSnackbar();
                    }
                }
                else {
                    notifyItemChanged(adapterPosition, null);
                    if (context instanceof MainActivity) {
                        ((MainActivity) context).showDisLikedSnackbar();
                    }
                }
                new LikeAsyncTask().execute("http://10.0.2.2:8080/pettown/like?pno="+
                        feedItems.get(adapterPosition).getpNo(),String.valueOf(adapterPosition));
            }
        });

        cellFeedViewHolder.ivUserProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onFeedItemClickListener.onProfileClick(view);
            }
        });
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int position) {
        Log.i(TAG,"onBindViewHolder");
        ((CellFeedViewHolder) viewHolder).bindView(feedItems.get(position));

        if (getItemViewType(position) == VIEW_TYPE_LOADER) {
            bindLoadingFeedItem((LoadingCellFeedViewHolder) viewHolder);
        }
    }

    private void bindLoadingFeedItem(final LoadingCellFeedViewHolder holder) {
        Log.i(TAG,"bindLoadingFeedItem");
        holder.loadingFeedItemView.setOnLoadingFinishedListener(new LoadingFeedItemView.OnLoadingFinishedListener() {
            @Override
            public void onLoadingFinished() {
                showLoadingView = false;
                notifyItemChanged(0);
            }
        });
        holder.loadingFeedItemView.startLoading();
    }

    @Override
    public int getItemViewType(int position) {
        if (showLoadingView && position == 0) {
            return VIEW_TYPE_LOADER;
        } else {
            return VIEW_TYPE_DEFAULT;
        }
    }

    @Override
    public int getItemCount() {
        return feedItems.size();
    }


    //피드 작성해서 리스트에 뿌려주기
    public void updateItems(boolean animated,int page){
        Log.i(TAG,"updateItems");
        new ItemsAsyncTask().execute("http://10.0.2.2:8080/pettown/feeds?page="+page);
        /*
        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable()  {
            public void run() {
                // 시간 지난 후 실행할 코딩
                //feedItems.clear();
                //addAll 함수에는 List 컬렉션 넣어주면 될꺼같다
                //for 문 돌려서 FeedItem 설정 후 List에 add 후 addAll로 넣어주기
                //feedItems.addAll(feedItemsTemp);
                if (animated) {
                    notifyItemRangeInserted(0, feedItems.size());
                } else {
                    notifyDataSetChanged();
                }
            }
        }, 1000); // 0.5초후
*/
        //feedItems.clear();
        //addAll 함수에는 List 컬렉션 넣어주면 될꺼같다
        //for 문 돌려서 FeedItem 설정 후 List에 add 후 addAll로 넣어주기
        //feedItems.addAll(feedItemsTemp);
        /*
        feedItems.addAll(Arrays.asList(
                new FeedItem("2","내용",null,"pet",
                        "lee","이길동","0","4.jpg",150,0),
                new FeedItem("3","내용",null,"pet",
                        "lee","이길동","0","3_2.jpg",150,0),
                new FeedItem("4","내용",null,"pet",
                        "lee","이길동","0","4_2.jpg",1340,0),
                new FeedItem("5","내용",null,"pet",
                        "lee","이길동","0","5_1.jpg",14,0),
                new FeedItem("6","내용",null,"pet",
                        "lee","이길동","0","bong.jpg",40,0)
                ));
        */



        if (animated) {
            //notifyItemRangeInserted(0, feedItems.size());
        } else {
           //notifyDataSetChanged();
        }
    }

    public void setOnFeedItemClickListener(OnFeedItemClickListener onFeedItemClickListener) {
        Log.i(TAG,"setOnFeedItemClickListener");
        this.onFeedItemClickListener = onFeedItemClickListener;
    }

    public void showLoadingView() {
        Log.i(TAG,"showLoadingView");
        showLoadingView = true;
        notifyItemChanged(0);
    }
    /////여기서 바인딩시키기
    public static class CellFeedViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.ivFeedCenter)
        ImageView ivFeedCenter;
        /*@BindView(R.id.ivFeedBottom)
        ImageView ivFeedBottom;*/
        @BindView(R.id.btnComments)
        ImageButton btnComments;
        @BindView(R.id.btnLike)
        ImageButton btnLike;
        @BindView(R.id.btnMore)
        ImageButton btnMore;
        @BindView(R.id.vBgLike)
        View vBgLike;
        @BindView(R.id.ivLike)
        ImageView ivLike;
        @BindView(R.id.tsLikesCounter)
        TextSwitcher tsLikesCounter;
        @BindView(R.id.ivUserProfile)
        ImageView ivUserProfile;
        @BindView(R.id.vImageRoot)
        FrameLayout vImageRoot;
        @BindView(R.id.ivFeedContent)
        TextView ivFeedContent;
        @BindView(R.id.ivUserName)
        TextView ivUserName;
        @BindView(R.id.ivFeedReplyName0)
        TextView ivFeedReplyName0;
        @BindView(R.id.ivFeedReplyContent0)
        TextView ivFeedReplyContent0;
        @BindView(R.id.ivFeedReplyName1)
        TextView ivFeedReplyName1;
        @BindView(R.id.ivFeedReplyContent1)
        TextView ivFeedReplyContent1;

        FeedItem feedItem;

        public CellFeedViewHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);
        }

        @SuppressLint("NewApi")
        public void bindView(FeedItem feedItem) {
            this.feedItem = feedItem;
            int adapterPosition = getAdapterPosition();
            //실제 사진
            Picasso.get().load(feedItem.getPrImage()).into(ivFeedCenter);
            //ivFeedCenter.setImageResource(adapterPosition % 2 == 0 ? R.drawable.img_feed_center_1 : R.drawable.img_feed_center_2);
            //여기에 텍스트 넣어야하는데 이미지뷰임 수정 필요
            Log.i(TAG,"텍스트뷰 세팅전");
            ivFeedContent.setText(feedItem.getpContent());
            ivUserName.setText(feedItem.getName());
            ivUserProfile.setBackground(new ShapeDrawable(new OvalShape()));
            ivUserProfile.setClipToOutline(true);

            for(int i = 0; i<feedItem.getPetReplyItem().size(); i++){
                if(i==0){
                    ivFeedReplyName0.setText(feedItem.getPetReplyItem().get(i).getName());
                    ivFeedReplyContent0.setText(feedItem.getPetReplyItem().get(i).getPrContent());
                }
                else{
                    ivFeedReplyName1.setText(feedItem.getPetReplyItem().get(i).getName());
                    ivFeedReplyContent1.setText(feedItem.getPetReplyItem().get(i).getPrContent());
                }
            }
            //Comments버튼 눌렀을때 전달할 값(글번호?)
            btnComments.setTag(feedItem.getpNo());
            Log.i(TAG,"글번호바인딩:"+feedItem.getpNo());
            Log.i(TAG,"텍스트뷰 세팅후");
            btnLike.setImageResource(feedItem.getIsLike()!=0 ? R.drawable.ic_heart_red : R.drawable.ic_heart_outline_grey);
            tsLikesCounter.setCurrentText(vImageRoot.getResources().getQuantityString(
                    R.plurals.likes_count, feedItem.getLikeCount(), feedItem.getLikeCount()
            ));
        }

        public FeedItem getFeedItem() {
            return feedItem;
        }
    }/////////////////CellFeedViewHolder

    public static class LoadingCellFeedViewHolder extends CellFeedViewHolder {

        LoadingFeedItemView loadingFeedItemView;

        public LoadingCellFeedViewHolder(LoadingFeedItemView view) {
            super(view);
            Log.i(TAG,"LoadingCellFeedViewHolder");
            this.loadingFeedItemView = view;
        }

        @Override
        public void bindView(FeedItem feedItem) {
            super.bindView(feedItem);
            Log.i(TAG,"LoadingCellFeedViewHolder - bindView");
        }
    }
    //실제 피드에 넣을 데이터를 여기에 추가해서 전달해주기
    public static class FeedItem {

        //글번호 저장용]
        private String pNo;
        //글내용 저장용]
        private String pContent;
        private Date pPostdate;
        private String pCategory;
        private String id;
        private String name;
        private String replyCount;
        //이미지 URL주소 저장용]
        private String prImage;
        private int likeCount;
        private int isLike;
        private List<PetReplyItem> petReplyItem;

        public FeedItem(String pNo, String pContent, Date pPostdate, String pCategory, String id, String name, String replyCount, String prImage, int likeCount, int isLike, List<PetReplyItem> petReplyItem) {
            this.pNo = pNo;
            this.pContent = pContent;
            this.pPostdate = pPostdate;
            this.pCategory = pCategory;
            this.id = id;
            this.name = name;
            this.replyCount = replyCount;
            this.prImage = prImage;
            this.likeCount = likeCount;
            this.isLike = isLike;
            this.petReplyItem = petReplyItem;
        }

        //게터]
        public String getpNo() {
            return pNo;
        }

        public void setpNo(String pNo) {
            this.pNo = pNo;
        }

        public String getpContent() {
            return pContent;
        }

        public void setpContent(String pContent) {
            this.pContent = pContent;
        }

        public Date getpPostdate() {
            return pPostdate;
        }

        public void setpPostdate(Date pPostdate) {
            this.pPostdate = pPostdate;
        }

        public String getpCategory() {
            return pCategory;
        }

        public void setpCategory(String pCategory) {
            this.pCategory = pCategory;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getReplyCount() {
            return replyCount;
        }

        public void setReplyCount(String replyCount) {
            this.replyCount = replyCount;
        }

        public String getPrImage() {
            return prImage;
        }

        public void setPrImage(String prImage) {
            this.prImage = prImage;
        }

        public int getLikeCount() {
            return likeCount;
        }

        public void setLikeCount(int likeCount) {
            this.likeCount = likeCount;
        }

        public int getIsLike() {
            return isLike;
        }

        public void setIsLike(int isLike) {
            this.isLike = isLike;
        }

        public List<PetReplyItem> getPetReplyItem() {
            return petReplyItem;
        }
        public void setPetReplyItem(List<PetReplyItem> petReplyItem) {
            this.petReplyItem = petReplyItem;
        }
    }//////////FeedItem



    public interface OnFeedItemClickListener {
        void onCommentsClick(View v, int position);

        void onMoreClick(View v, int position);

        void onProfileClick(View v);
    }


    //데이터 리스트 받기
    public class ItemsAsyncTask extends AsyncTask<String,Void,Void> {
        @Override
        protected Void doInBackground(String... params) {
            feedItemsTemp.clear();
            StringBuffer buf = new StringBuffer();
            try {
                URL url = new URL(params[0]);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                //서버에 요청 및 응답코드 받기
                int responseCode = conn.getResponseCode();
                if(responseCode==HttpURLConnection.HTTP_OK){
                    //연결된 커넥션에서 서버에서 보낸 데이타 읽기
                    BufferedReader br =
                            new BufferedReader(
                                    new InputStreamReader(conn.getInputStream(),"UTF-8"));
                    String line;
                    while((line=br.readLine())!=null){
                        buf.append(line);
                    }
                    br.close();
                    //JSON데이타 파싱
                    Log.i(TAG,buf.toString());
                    JSONArray array= new JSONArray(buf.toString());
                    for(int i=0;i<array.length();i++){
                        Log.i(TAG,"for문 입장 횟수"+array.length());
                        JSONObject json = array.getJSONObject(i);
                        String pNo = json.getString("pNo");
                        String pContent = json.getString("pContent");
                        Date pPostdate = new Date(Long.parseLong(json.getString("pPostdate")));
                        String pCategory = json.getString("pCategory");
                        String id = json.getString("id");
                        String name = json.getString("name");
                        String replyCount = json.getString("replyCount");
                        JSONArray prImages = json.getJSONArray("prImage");
                        String prImage = IMAGE_URL+"upload1.jpg";
                        if(prImages.length() != 0)
                            prImage = IMAGE_URL+json.getJSONArray("prImage").get(0);
                        int likeCount = json.getInt("likeCount");
                        int isLike = json.getInt("isLike");
                        JSONArray petReplys = json.getJSONArray("petReply");
                        List<PetReplyItem> petReplyItemList = new Vector<PetReplyItem>();
                        if(petReplys.length() != 0){
                            for(int k=0;k < petReplys.length();k++){
                                Log.i(TAG,"댓글 포문 입장");
                                PetReplyItem petReplyItem = new PetReplyItem();
                                JSONObject reply = (JSONObject)petReplys.get(k);
                                Log.i(TAG,"댓글내용:"+reply.getString("prContent"));
                                petReplyItem.setId(reply.getString("id"));
                                petReplyItem.setMpPhoto(reply.getString("mpPhoto"));
                                petReplyItem.setPrNo(reply.getString("prNo"));
                                petReplyItem.setPrContent(reply.getString("prContent"));
                                petReplyItem.setName(reply.getString("name"));
                                petReplyItemList.add(petReplyItem);
                            }
                            //"petReply":[{"prNo":"4","prContent":"댓글3333",
                            // "prPostdate":1592146800000,
                            // "id":"park@naver.com",
                            // "pNo":"16","name":"박길동","mpPhoto":null},
                        }
                        Log.i(TAG,"번호"+pNo);
                        /*
                        Log.i(TAG,"내용"+pContent);
                        Log.i(TAG,"날짜"+pPostdate);
                        Log.i(TAG,"카테고리"+pCategory);
                        Log.i(TAG,"아이디"+id);
                        Log.i(TAG,"이름"+name);
                        Log.i(TAG,"댓글"+replyCount);
                        Log.i(TAG,"이미지"+prImage);
                        Log.i(TAG,"좋아요수"+likeCount);
                        Log.i(TAG,"좋아요 여부"+isLike);
                        */
                        FeedItem item = new FeedItem(pNo,pContent,pPostdate,pCategory,id,name,
                                replyCount,prImage,likeCount,isLike, petReplyItemList);
                        feedItemsTemp.add(item);
                    }
                    feedItems.addAll(feedItemsTemp);

                }
            }
            catch(Exception e){e.printStackTrace();}
            return null;
        }
        @Override
        protected void onPostExecute(Void aVoid) {
            //어댑터에게 데이터 변경 통지
            notifyItemRangeInserted(feedItems.size()-feedItemsTemp.size(), feedItems.size());
        }
    }/////////////////////ItemsAsyncTask

    //좋아요 체크
    public class LikeAsyncTask extends AsyncTask<String,Void,Void> {
        @Override
        protected Void doInBackground(String... params) {
            StringBuffer buf = new StringBuffer();
            try {
                URL url = new URL(params[0]);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                //서버에 요청 및 응답코드 받기
                int responseCode = conn.getResponseCode();
                if(responseCode==HttpURLConnection.HTTP_OK){
                    //연결된 커넥션에서 서버에서 보낸 데이타 읽기
                    BufferedReader br =
                            new BufferedReader(
                                    new InputStreamReader(conn.getInputStream(),"UTF-8"));
                    String line;
                    while((line=br.readLine())!=null){
                        buf.append(line);
                    }
                    br.close();
                    //JSON데이타 파싱
                    Log.i(TAG,buf.toString());
                    feedItems.get(Integer.parseInt(params[1])).setLikeCount(Integer.parseInt(buf.toString()));
                }
            }
            catch(Exception e){e.printStackTrace();}
            return null;
        }
        @Override
        protected void onPostExecute(Void aVoid) {
            //어댑터에게 데이터 변경 통지

        }
    }/////////////////////ItemsAsyncTask

}///////class
